setwd('C:\\Users\\NT500R\\Desktop\\선생님 분석')

library(readxl)
data <- read_excel(path = 'data.xlsx', sheet = 'Sheet1', col_names = TRUE)
str(data)

colnames(data) <- c('Q11','Q12','Q13','Q14','Q15','Q16','Q21','Q22','Q23','Q24','Q25','Q26','Q27','지역','직급','성별','경력','학교형태','규모')
str(data)

data$지역 <- as.factor(data$지역)
data$직급 <- as.factor(data$직급)
data$성별 <- as.factor(data$성별)
data$경력 <- as.factor(data$경력)
data$학교형태 <- as.factor(data$학교형태)
data$규모 <- as.factor(data$규모)
str(data)

library(ggplot2)
library(dplyr)

na_data <- union(which(is.na(data$Q11)), #설문지 내용 중 NA 인 데이터 처리를 위한 작업.
c(which(is.na(data$Q12)),
which(is.na(data$Q13)),
which(is.na(data$Q14)),
which(is.na(data$Q15)),
which(is.na(data$Q16)),
which(is.na(data$Q21)),
which(is.na(data$Q22)),
which(is.na(data$Q23)),
which(is.na(data$Q24)),
which(is.na(data$Q25)),
which(is.na(data$Q26)),
which(is.na(data$Q27))))
na_data #12개의 NA발견

data1 <- data[-c(na_data),] #NA데이터를 뺀 데이터셋 만듦.

str(data1) #12개의 NA데이터 빠진것으로 유추.

data1$Q1 <- data1$Q11+data1$Q12+data1$Q13+data1$Q14+data1$Q15+data1$Q16 #1번 문항 합계
data1$Q2 <- data1$Q21+data1$Q22+data1$Q23+data1$Q24+data1$Q25+data1$Q26+data1$Q27 #2번 문항 합계
data1$Q3 <- data1$Q1 + data1$Q2 #모든문항 합계
str(data1)

sum(is.na(data1$지역))
which(is.na(data1$직급)) #1개 -> 교사 위주로 점수를 볼 것 이므로 직급을 적지않은 데이터는 삭제.
which(is.na(data1$경력)) #2개 -> 경력에 따른 점수는 의미 x
which(is.na(data1$학교형태)) #5개 -> 학교형태에 따른 점수를 보는것이 관건 -> 학교형태를 모르는 데이터는 삭제하기로 결정

na_re <- union(which(is.na(data1$직급)), c(which(is.na(data1$학교형태))))
data2 <- data1[-c(na_re),]
str(data2)


###########분석#############
data2 %>%
  ggplot(aes(x=`성별`,fill=`성별`))+geom_bar()+
  geom_text(aes( label = ..count..), stat= "count",position=position_stack(.5))


data2 %>%
  ggplot(aes(x=`지역`,fill=`지역`))+geom_bar()+
  geom_text(aes( label = ..count..), stat= "count",position=position_stack(.5))

data3 <- data2[,c('지역','Q1','Q2','Q3')]

data_w <- data3[which(data3[,'지역']=='서부권'),c(2,3,4)]
data_e <- data3[-which(data3[,'지역']=='서부권'),c(2,3,4)]

m_w <- apply(data_w,2,mean)
m_e <- apply(data_e,2,mean)

m <-  as.data.frame(rbind(m_w,m_e))
rownames(m) <- c('서부권','동부권')
m$locate <- c('서부권','동부권')

m %>%
  ggplot(aes(x=locate,y=Q1,fill=locate))+geom_bar(stat='identity')+
  geom_text(aes( label = Q1),position=position_stack(.7))+ggtitle('Q1에 대한 지역별 점수 평균')
  

m %>%
  ggplot(aes(x=locate,y=Q2,fill=locate))+geom_bar(stat='identity')+
  geom_text(aes( label = Q2),position=position_stack(.7))+ggtitle('Q2에 대한 지역별 점수 평균')

m %>%
  ggplot(aes(x=locate,y=Q3,fill=locate))+geom_bar(stat='identity')+
  geom_text(aes( label = Q3),position=position_stack(.7))+ggtitle('전체에 대한 지역별 점수 평균')


data4 <- data2[,c(14:22)]

school <- data4 %>%
  group_by(학교형태) %>%
  summarise(mQ1 = mean(Q1), mQ2 = mean(Q2), mQ3 = mean(Q3))

school %>%
  ggplot(aes(x=학교형태,y=mQ1,fill=학교형태))+geom_bar(stat='identity')+
  geom_text(aes( label = mQ1),position=position_stack(.7))+ggtitle('Q1에 대한 학교형태별 점수 평균')

school %>%
  ggplot(aes(x=학교형태,y=mQ2,fill=학교형태))+geom_bar(stat='identity')+
  geom_text(aes( label = mQ2),position=position_stack(.7))+ggtitle('Q2에 대한 학교형태별 점수 평균')

school %>%
  ggplot(aes(x=학교형태,y=mQ3,fill=학교형태))+geom_bar(stat='identity')+
  geom_text(aes( label = mQ3),position=position_stack(.7))+ggtitle('전체에 대한 학교형태별 점수 평균')




X <- data4 %>%
  group_by(학교형태,규모) %>%
  summarise(mQ1 = mean(Q1), mQ2 = mean(Q2), mQ3 = mean(Q3))

X %>%
  ggplot(aes(x=학교형태,y=mQ1))+geom_bar(aes(fill=규모),stat='identity',position=position_dodge())+ggtitle('Q1에 대한 학교형태별 점수 평균')


X %>%
  ggplot(aes(x=학교형태,y=mQ2))+geom_bar(aes(fill=규모),stat='identity',position=position_dodge())+ggtitle('Q2에 대한 학교형태별 점수 평균')



X %>%
  ggplot(aes(x=학교형태,y=mQ3))+geom_bar(aes(fill=규모),stat='identity',position=position_dodge())+ggtitle('전체에 대한 학교형태별 점수 평균')








